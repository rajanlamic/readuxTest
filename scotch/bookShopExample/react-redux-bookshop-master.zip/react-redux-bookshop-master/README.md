## Bookshop with React-Redux for Scotch

This demo backs a Scotch article and is intended to be used along with them demo.

Each part on the article has a respective branch and the master branch is the final example

Clone, install packages and run:

```bash

npm start

```
